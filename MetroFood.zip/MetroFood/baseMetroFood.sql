CREATE DATABASE baseMetroFood;

USE baseMetroFood;

CREATE TABLE Rol(
idTipoUsuario INT NOT NULL,
rol VARCHAR (15) NOT NULL
);

CREATE TABLE Usuario(
idUsuario INT NOT NULL AUTO_INCREMENT,
nombreUsuario VARCHAR(30) NOT NULL,
contrasenha VARCHAR(12) NOT NULL,
idTipoUsuario INT NOT NULL,
PRIMARY KEY(idUsuario)
);

CREATE TABLE Cliente(
idCliente INT NOT NULL AUTO_INCREMENT,
idUsuario INT NOT NULL,
nombre VARCHAR(30) NOT NULL,
apellido VARCHAR(30) NOT NULL,
edad INT NOT NULL,
DUI VARCHAR(11) NOT NULL,
telefonoCliente VARCHAR(9) NOT NULL,
direccion VARCHAR(50) NOT NULL,
correo VARCHAR(30) NOT NULL,
PRIMARY KEY(idCliente)
);

CREATE TABLE Pedido(
idPedido INT NOT NULL AUTO_INCREMENT,
idCliente INT NOT NULL,
fechaPedido DATE NOT NULL,
fechaEntrega DATE NOT NULL,
totalPagar DECIMAL(5,2) NOT NULL,
estadoPedido VARCHAR(15) NOT NULL,
PRIMARY KEY(idPedido)
);

CREATE TABLE DetallePedido(
idPedido INT NOT NULL,
idProducto INT NOT NULL,
cantidad INT NOT NULL,
subtotalPagar DECIMAL(5,2) NOT NULL,
PRIMARY KEY (idPedido, idProducto)
);

CREATE TABLE Producto(
idProducto INT NOT NULL AUTO_INCREMENT,
idRestaurante INT NOT NULL,
nombreProducto VARCHAR (30) NOT NULL,
precio DECIMAL(5,2) NOT NULL,
PRIMARY KEY(idProducto)
);

CREATE TABLE DetalleMenuProducto(
idDetalleMenuProducto INT NOT NULL AUTO_INCREMENT,
idProducto INT NOT NULL,
idMenu INT NOT NULL,
PRIMARY KEY(idDetalleMenuProducto)
);

CREATE TABLE Menu(
idMenu INT NOT NULL AUTO_INCREMENT,
idRestaurante INT NOT NULL,
catergoriaMenu VARCHAR(30) NOT NULL,
PRIMARY KEY(idMenu)
);

CREATE TABLE Restaurante(
idRestaurante INT NOT NULL AUTO_INCREMENT,
idUsuario INT NOT NULL,
codigoTributario VARCHAR(10) NOT NULL,
nombreRestaurante VARCHAR(30) NOT NULL,
direccionRestaurante VARCHAR(50) NOT NULL,
telefonoRestaurante VARCHAR(9) NOT NULL,
ciudad VARCHAR(15),
PRIMARY KEY (idRestaurante)
);


ALTER TABLE Rol ADD CONSTRAINT pk_Rol PRIMARY KEY(idTipoUsuario);
ALTER TABLE Usuario ADD CONSTRAINT pk_Usuario PRIMARY KEY(idUsuario);
ALTER TABLE Cliente ADD CONSTRAINT pk_Cliente PRIMARY KEY(idCliente);
ALTER TABLE Pedido ADD CONSTRAINT pk_Pedido PRIMARY KEY(idPedido);
ALTER TABLE DetallePedido ADD CONSTRAINT pk_DetallePedido PRIMARY KEY(idPedido, idProducto);
ALTER TABLE Producto ADD CONSTRAINT pk_Producto PRIMARY KEY(idProducto);
ALTER TABLE Menu ADD CONSTRAINT pk_Menu PRIMARY KEY(idProducto, idRestaurante);
ALTER TABLE Restaurante ADD CONSTRAINT pk_Restaurante PRIMARY KEY(idRestaurante);

ALTER TABLE Usuario ADD CONSTRAINT fk_UsuarioRol FOREIGN KEY (idTipoUsuario) REFERENCES Rol(idTipoUsuario);
ALTER TABLE Cliente ADD CONSTRAINT fk_ClienteUsuario FOREIGN KEY(idUsuario) REFERENCES Usuario(idUsuario); 
ALTER TABLE Pedido ADD CONSTRAINT fk_PedidoCliente FOREIGN KEY(idCliente) REFERENCES Cliente(idCliente);
ALTER TABLE DetallePedido ADD CONSTRAINT fk_DetallePedidoPedido FOREIGN KEY(idPedido) REFERENCES Pedido(idPedido);
ALTER TABLE DetallePedido ADD CONSTRAINT fk_DetallePedidoProducto FOREIGN KEY(idProducto) REFERENCES Producto(idProducto);
ALTER TABLE Menu ADD CONSTRAINT fk_MenuProducto FOREIGN KEY(idProducto) REFERENCES Producto(idProducto);
ALTER TABLE Menu ADD CONSTRAINT fk_MenuRestaurante FOREIGN KEY(idRestaurante) REFERENCES Restaurante(idRestaurante);
ALTER TABLE Restaurante ADD CONSTRAINT fk_RestauranteUsuario FOREIGN KEY(idUsuario) REFERENCES Usuario(idUsuario);







