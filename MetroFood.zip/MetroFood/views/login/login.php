<?php 
session_start();
if (isset($_SESSION['ROL'])) {
	header("Location: ../../login.php");
}


 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="../../pluggins/bootstrap/css/bootstrap.css">
	<script src="../../pluggins/jquery-3.3.1.js"></script>
	<script src="../../pluggins/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="../../css/css.css">
	<!--<script type="text/javascript" src="../../javascript/roles.js"></script>-->
</head>
<body background="../../img/wallpaper.jpg">
	<div class="jumbotron boxlogin">
		<center><h3><b>METROFOOD</b></h3></center> <br>
		<form method="POST" action="../../php/verificacion.php">
			<div class="form-column col-md-12 col-sm-12 col-xs-12">
				<div class="form-group">
					<label for="usuario" class="control-label">Nombre de usuario: </label>
					<input class="form-control" type="text" name="user">
					<label for="pass" class="control-label">Contraseña: </label>
					<input class="form-control" type="password" name="pass">
				</div>
			</div>
			<div class="form-column col-md-12 col-sm-12 col-xs-12">
				<div class="form-group">
					<a class="link" href="#">¿Olvidó su contraseña?</a>
					<a class="link" href="../registrar/registrar_usuario.php">Registrarse</a>
				</div>
			</div>
			<br>
			<div class="clearfix"></div>
			<center>
				<div class="form-column col-md-12 col-sm-12 col-xs-12">
					<div class="form-group">
						<input class="btn btn-info" type="submit" id="enviarDatos" name="enviarDatos" value="Iniciar">
					</div>
					<span id="resultado"></span>
				</div>
			</center>
		</form>
	</div>
</body>

</html>
