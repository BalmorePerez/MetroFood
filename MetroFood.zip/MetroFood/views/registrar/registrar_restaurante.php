<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Tu restaurante en MetroFood</title>

    <!-- Bootstrap core CSS -->
    <link href="../dashboard/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../dashboard/css/shop-homepage.css" rel="stylesheet">

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #FA8072;">
      <div class="container">
        <a class="navbar-brand" href="#">MetroFood</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Services</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <div class="col-lg-3">

          <h1 class="my-4">Registra tu restaurante</h1>
          <div class="list-group">
            <a href="registrar_usuario.php" class="list-group-item">Regresar a cliente</a>
            <a href="#" class="list-group-item">Category 2</a>
            <a href="#" class="list-group-item">Category 3</a>
          </div>

        </div>
        <!-- /.col-lg-3 -->
        

        <div class="col-lg-9">
<form action="../../php/controllerRegistroUsuarios.php" method="POST">
          <div class="row">

          	<div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                  </h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                  </h5>
                </div>
              </div>

            <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                    Nombre de usuario
                  </h5>
                  <input type="text" class='form-control' name="nombreUsuario">
                </div>
              </div>
            

            <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                    Contraseña
                  </h5>
                  <input type="password" class='form-control' name="password">
                </div>
              </div>

            <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                    Repetir contraseña
                  </h5>
                  <input type="password" class='form-control' name="repeatPassword">
                </div>
              </div>

            <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                    Nombre de contacto
                  </h5>
                  <input type="text" class='form-control' name="nombreContacto">
                </div>
              </div>
            

            <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                    Nombre del restaurante
                  </h5>
                  <input type="text" class='form-control' name="nombreRestaurante">
                </div>
              </div>

              <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                    Email
                  </h5>
                  <input type="text" class='form-control' name="email">
                </div>
              </div>

              <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                    Teléfono(s)
                  </h5>
                  <input type="text" class='form-control' name="telefono">
                </div>
              </div>

              <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                    Dirección
                  </h5>
                  <input type="text" class='form-control' name="direccion">
                </div>
              </div>

              <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                    Ciudad
                  </h5>
                  <input type="text" class='form-control' name="ciudad">
                </div>
              </div>

              <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                    Cantidad de sucursales
                  </h5>
                  <input type="text" class='form-control' name="cantidadSucursales">
                </div>
              </div>

              <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                    Número de Código Tributario
                  </h5>
                  <input type="text" class='form-control' name="codigoTributario">
                </div>
              </div>

              <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <h5 class='form-group'>
                    Logo del restaurante
                  </h5>
                  <input type="file" class='form-control' name="logoRestaurante">
                </div>
              </div>

              <div class="col-lg-6 col-md-6 mb-4">
                <div class="card-body">
                  <input type="submit" class='btn btn-success' name="enviarDatosRestaurante" class='form-control' value="Registrar datos">
                </div>
              </div>
          </div>
        </div>
      </form>
      </div>
    </div>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2018</p>
      </div>
      <!-- /.container -->
    </footer>


    <!-- Bootstrap core JavaScript -->
    <script src="../../js/jquery-3.3.1.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
