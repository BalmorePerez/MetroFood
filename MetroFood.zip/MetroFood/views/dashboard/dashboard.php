<?php 

  require_once '../../app/validacionGeneral.php';  

 
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>METROFOOD - DASHBOARD</title>
	
</head>
<body>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Shop Homepage - Start Bootstrap Template</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/shop-homepage.css" rel="stylesheet">

  </head>

  <body>
   <?php 

  if($_SESSION['ROL'] == 'Restaurante'){
    echo "<!-- Navigation -->
    <nav class='navbar navbar-expand-lg navbar-dark fixed-top' style='background-color: #FF5733;>
      <div class='container'>
        <a class='navbar-brand' href='#'>MetroFood</a>
        <button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarResponsive' aria-controls='navbarResponsive' aria-expanded='false' aria-label='Toggle navigation'>
          <span class='navbar-toggler-icon'></span>
        </button>
        <div class='collapse navbar-collapse' id='navbarResponsive'>
          <ul class='navbar-nav ml-auto'>
            <li class='nav-item active'>
              <a class='nav-link' href='#'>Home
                <span class='sr-only'>(current)</span>
              </a>
            </li>
            <li class='nav-item'>
              <a class='nav-link' href='#'>Catálogo</a>
            </li>
            <li class='nav-item'>
              <a class='nav-link' href='#'>Pedidos</a>
            </li>
            <li class='nav-item'>
              <a class='nav-link' href='#'>Nuestro perfil</a>
            </li>
            <li class='nav-item'>
              <a class='nav-link' href='../../php/logout.php'>Cerrar Sesion</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Page Content -->
    <div class='container'>

      <div class='row'>

        <div class='col-lg-3'>

          <div class='thumbnail'><img src='Ejemplo.png' width='150' height='150'></div>
          <h1 class='my-4'>Shop Name</h1>
          <div class='list-group'>
            <a href='#' class='list-group-item'>Category 1</a>
            <a href='#' class='list-group-item'>Category 2</a>
            <a href='#' class='list-group-item'>Category 3</a>
          </div>

        </div>
        <!-- /.col-lg-3 -->

        <div class='col-lg-9'>
          <div class='row' style='margin-top: 100px;'>
            <h2>Pedidos</h2>
            <br>
              <p>Lista de pedidos agregados recientemente</p>
              <br>           
              <table class='table table-hover' style=''>
                <thead>
                  <tr>
                    <th>No. Pedido</th>
                    <th>No. Cliente</th>
                    <th>Fecha Pedido</th>
                    <th>Fecha Entrega</th>
                    <th>Total a pagar</th>
                    <th>Estado</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>195717</td>
                    <td>00059</td>
                    <td>20/03/2018</td>
                    <td>20/03/2018</td>
                    <td>21.36</td>
                    <td><select class='form-control'><option>Pendiente</option><option>Enviado</option><option>Entregado</option></select></td>
                  </tr>
                  <tr>
                    <td>195717</td>
                    <td>00059</td>
                    <td>20/03/2018</td>
                    <td>20/03/2018</td>
                    <td>21.36</td>
                    <td><select class='form-control'><option>Pendiente</option><option>Enviado</option><option>Entregado</option></select></td>
                  </tr>
                  <tr>
                    <td>195717</td>
                    <td>00059</td>
                    <td>20/03/2018</td>
                    <td>20/03/2018</td>
                    <td>21.36</td>
                    <td><select class='form-control'><option>Pendiente</option><option>Enviado</option><option>Entregado</option></select>
                    </td>
                  </tr>
                </tbody>
              </table>
          </div>
          <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class='py-5 bg-light'>
      <div class='container'>
        <p class='m-0 text-center text-black'>Copyright &copy; Your Website 2017</p>
      </div>
      <!-- /.container -->
    </footer>
";
  }
  else{
    echo "<!-- Navigation -->
    <nav class='navbar navbar-expand-lg navbar-dark fixed-top' style='background-color: #FF5733;>
      <div class='container'>
        <a class='navbar-brand' href='#'>Inicio</a>
        <button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarResponsive' aria-controls='navbarResponsive' aria-expanded='false' aria-label='Toggle navigation'>
          <span class='navbar-toggler-icon'></span>
        </button>
        <div class='collapse navbar-collapse' id='navbarResponsive'>
          <ul class='navbar-nav ml-auto'>
            <li class='nav-item active'>
              <a class='nav-link' href='#'>Home
                <span class='sr-only'>(current)</span>
              </a>
            </li>
            <li class='nav-item'>
              <a class='nav-link' href='#'>Catálogo</a>
            </li>
            <li class='nav-item'>
              <a class='nav-link' href='#'>Pedidos</a>
            </li>
            <li class='nav-item'>
              <a class='nav-link' href='#'>Perfil</a>
            </li>
            <li class='nav-item'>
              <a class='nav-link' href='../../php/logout.php'>Cerrar Sesion</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Page Content -->
    <div class='container'>

      <div class='row'>

        <div class='col-lg-3'>

          <h1 class='my-4'>MetroFood</h1>
          <div class='list-group'>
            <a href='#' class='list-group-item'>Comida Rápida</a>
            <a href='#' class='list-group-item'>Comida Mexicana</a>
            <a href='#' class='list-group-item'>Comida China</a>
          </div>

        </div>
        <!-- /.col-lg-3 -->

        <div class='col-lg-9'>

          <div id='carouselExampleIndicators' class='carousel slide my-4' data-ride='carousel'>
            <ol class='carousel-indicators'>
              <li data-target='#carouselExampleIndicators' data-slide-to='0' class='active'></li>
              <li data-target='#carouselExampleIndicators' data-slide-to='1'></li>
              <li data-target='#carouselExampleIndicators' data-slide-to='2'></li>
            </ol>
            <div class='carousel-inner' role='listbox'>
              <div class='carousel-item active'>
                <img class='d-block img-fluid' src='../img/royalewithcheese.jpg' alt='First slide'>
              </div>
              <div class='carousel-item'>
                <img class='d-block img-fluid' src='../img/submarino.jpg' alt='Second slide'>
              </div>
              <div class='carousel-item'>
                <img class='d-block img-fluid' src='../img/torta.jpg' alt='Third slide'>
              </div>
            </div>
            <a class='carousel-control-prev' href='#carouselExampleIndicators' role='button' data-slide='prev'>
              <span class='carousel-control-prev-icon' aria-hidden='true'></span>
              <span class='sr-only'>Previous</span>
            </a>
            <a class='carousel-control-next' href='#carouselExampleIndicators' role='button' data-slide='next'>
              <span class='carousel-control-next-icon' aria-hidden='true'></span>
              <span class='sr-only'>Next</span>
            </a>
          </div>

          <div class='row'>

            <div class='col-lg-4 col-md-6 mb-4'>
              <div class='card h-100'>
                <a href='#'><img class='card-img-top' height='200' weight='700' src='../img/alitas.jpg' alt=''></a>
                <div class='card-body'>
                  <h4 class='card-title'>
                    <a href='#'>Alitas BBQ</a>
                  </h4>
                  <h5>$9.99</h5>
                  <p class='card-text'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur!</p>
                </div>
                <div class='card-footer'>
                  <small class='text-muted'>&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class='col-lg-4 col-md-6 mb-4'>
              <div class='card h-100'>
                <a href='#'><img class='card-img-top' height='200' weight='700' src='../img/calzone.png' alt=''></a>
                <div class='card-body'>
                  <h4 class='card-title'>
                    <a href='#'>Calzone</a>
                  </h4>
                  <h5>$3.99</h5>
                  <p class='card-text'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur! Lorem ipsum dolor sit amet.</p>
                </div>
                <div class='card-footer'>
                  <small class='text-muted'>&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class='col-lg-4 col-md-6 mb-4'>
              <div class='card h-100'>
                <a href='#'><img class='card-img-top' height='200' weight='700' src='../img/chaomein.jpg' alt=''></a>
                <div class='card-body'>
                  <h4 class='card-title'>
                    <a href='#'>Chao mein</a>
                  </h4>
                  <h5>$12.99</h5>
                  <p class='card-text'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur!</p>
                </div>
                <div class='card-footer'>
                  <small class='text-muted'>&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class='col-lg-4 col-md-6 mb-4'>
              <div class='card h-100'>
                <a href='#'><img class='card-img-top' height='200' weight='700' src='../img/hotdog.jpg' alt=''></a>
                <div class='card-body'>
                  <h4 class='card-title'>
                    <a href='#'>Combo hot dog</a>
                  </h4>
                  <h5>$5.99</h5>
                  <p class='card-text'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur!</p>
                </div>
                <div class='card-footer'>
                  <small class='text-muted'>&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class='col-lg-4 col-md-6 mb-4'>
              <div class='card h-100'>
                <a href='#'><img class='card-img-top' height='200' weight='700' src='../img/pizza.jpg' alt=''></a>
                <div class='card-body'>
                  <h4 class='card-title'>
                    <a href='#'>Pizza hawaiana</a>
                  </h4>
                  <h5>$12.99</h5>
                  <p class='card-text'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur! Lorem ipsum dolor sit amet.</p>
                </div>
                <div class='card-footer'>
                  <small class='text-muted'>&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

            <div class='col-lg-4 col-md-6 mb-4'>
              <div class='card h-100'>
                <a href='#'><img class='card-img-top' height='200' weight='700' src='../img/posho.jpg' alt=''></a>
                <div class='card-body'>
                  <h4 class='card-title'>
                    <a href='#'>Combo pollo frito</a>
                  </h4>
                  <h5>$10.99</h5>
                  <p class='card-text'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur!</p>
                </div>
                <div class='card-footer'>
                  <small class='text-muted'>&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                </div>
              </div>
            </div>

          </div>
          <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<!-- /.container -->

    <!-- Footer -->
    <footer class='py-5 bg-dark'>
      <div class='container'>
        <p class='m-0 text-center text-white'>Copyright &copy; Your Website 2017</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src='vendor/jquery/jquery.min.js'></script>
    <script src='vendor/bootstrap/js/bootstrap.bundle.min.js'></script>";
  }

   ?>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
</body>
</html>