<?php 

session_start();

if ($_SESSION['ROL']=='Restaurante' || $_SESSION['ROL']=='Cliente' ) {
	
}else{
	header("Location:../login/login.php");
	
}




 ?>