<?php 
mysqli_close("conexion.php");
 ?>