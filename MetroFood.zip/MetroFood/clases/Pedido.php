<?php 
/**
* 
*/
class Pedido
{
	protected $idCliente;
	protected $fechaPedido;
	protected $fechaEntrega;
	protected $totalPagar;
	protected $estadoPedido;
	function __construct()
	{
		# code...
	}
	public function getIdCliente()
	{
		return $this->idCliente;
	}
	public function setIdCliente($idCliente)
	{
		$this->idCliente = $idCliente;
	}
	public function getFechaPedido()
	{
		return $this->fechaPedido;
	}
	public function setFechaPedido($fechaPedido)
	{
		$this->fechaPedido = $fechaPedido;
	}
	public function getFechaEntrega()
	{
		return $this->fechaEntrega;
	}
	public function setFechaEntrega($fechaEntrega)
	{
		$this->fechaEntrega = $fechaEntrega;
	}
	public function getTotalPagar()
	{
		return $this->totalPagar;
	}
	public function setTotalPagar($totalPagar)
	{
		$this->totalPagar = $totalPagar;
	}
	public function getEstadoPedido()
	{
		return $this->estadoPedido;
	}
	public function setEstadoPedido($estadoPedido)
	{
		$this->estadoPedido = $estadoPedido;
	}
}
 ?>