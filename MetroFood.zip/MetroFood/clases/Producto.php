<?php 
/**
* 
*/
class Producto
{
	protected $nombreProducto;
	protected $precio;
	function __construct()
	{
		# code...
	}

	public function getNombreProducto()
	{
		return $this->nombreProducto;
	}
	public function setNombreProducto($nombreProducto)
	{
		$this->nombreProducto = $nombreProducto;
	}
	public function getPrecio()
	{
		return $this->precio;
	}
	public function setPrecio($precio)
	{
		$this->precio = $precio;
	}
}
 ?>