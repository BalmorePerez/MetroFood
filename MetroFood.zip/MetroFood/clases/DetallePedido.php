<?php 
/**
* 
*/
class DetallePedido
{
	protected $idPedido;
	protected $idProducto;
	protected $cantidad;
	protected $subtotalPagar;
	function __construct()
	{
		# code...
	}

	public function getIdPedido()
	{
		return $this->idPedido = $idPedido;
	}
	public function setIdPedido($idPedido)
	{
		$this->idPedido = $idPedido;
	}
	public function getIdProducto()
	{
		return $this->idProducto = $idProducto;
	}
	public function setIdProducto($idProducto)
	{
		$this->idProducto = $idProducto;
	}
	public function getCantidad()
	{
		return $this->cantidad;
	}
	public function setCantidad($cantidad)
	{
		$this->cantidad = $cantidad;
	}
	public function getSubTotalPagar()
	{
		return $this->subtotalPagar;
	}
	public function setSubTotalPagar($subtotalPagar)
	{
		$this->subtotalPagar = $subtotalPagar;
	}
}
 ?>