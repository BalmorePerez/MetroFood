<?php 
/**
* 
*/
class Menu
{
	protected $idMenu;
	protected $idRestaurante;
	protected $catergoriaMenu;
	function __construct()
	{
		# code...
	}
	public function getIdMenu()
	{
		return $this->idMenu = $idMenu;
	}
	public function setIdMenu($idMenu)
	{
		$this->idMenu = $idMenu;
	}
	public function getIdRestaurante()
	{
		return $this->idRestaurante;
	}
	public function setIdRestaurante($idRestaurante)
	{
		$this->idRestaurante = $idRestaurante;
	}
	public function getCategoriaMenu()
	{
		return $this->catergoriaMenu;
	}
	public function setCategoriaMenu($catergoriaMenu)
	{
		$this->catergoriaMenu = $catergoriaMenu;
	}
}
 ?>