<?php 
/**
* 
*/
class DetalleMenuProducto
{
	protected $idProducto;
	protected $idMenu;
	
	function __construct()
	{
		# code...
	}

	public function getIdProducto()
	{
		return $this->idProducto;
	}
	public function setIdProducto($idProducto)
	{
		$this->idProducto = $idProducto;
	}
	public function getIdMenu()
	{
		return $this->idMenu;
	}
	public function setIdMenu($idMenu)
	{
		$this->idMenu = $idMenu;
	}

}




 ?>