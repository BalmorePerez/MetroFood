<?php 
require_once 'Conexion.php';
//require_once 'Usuario.php';
/**
* 
*/
class Restaurante extends Conexion
{
	protected $idUsuario;
	protected $codigoTributario;
	protected $nombreRestaurante;
	protected $direccionRestaurante;
	protected $telefonoRestaurante;
	protected $ciudad;
	protected $email;
	protected $cantidadSucursales;
	protected $logo;
	function __construct()
	{
		parent::__construct();
	}
	public function getIdUsuario()
	{
		return $this->idUsuario;
	}
	public function setIdUsuario($idUsuario)
	{
		$this->idUsuario = $idUsuario;
	}
	public function getCodigoTributario()
	{
		return $this->codigoTributario;
	}
	public function setCodigoTributario($idCodigo)
	{
		$this->codigoTributario = $codigoTributario;
	}
	public function getNombreRestaurante()
	{
		return $this->nombreRestaurante;
	}
	public function setNombreRestaurante($nombreRestaurante)
	{
		$this->nombreRestaurante = $nombreRestaurante;
	}
	public function getDireccionRestaurante()
	{
		return $this->direccionRestaurante = $direccionRestaurante;
	}
	public function setDireccionRestuarante($direccionRestaurante)
	{
		$this->direccionRestaurante = $direccionRestaurante;
	}
	public function getTelefonoRestaurante()
	{
		return $this->telefonoRestaurante = $telefonoRestaurante;
	}
	public function setTelefonoRestaurante($telefonoRestaurante)
	{
		$this->telefonoRestaurante = $telefonoRestaurante;
	}
	public function getCiudad()
	{
		return $this->ciudad = $ciudad;
	}
	public function setCiudad($ciudad)
	{
		$this->ciudad = $ciudad;
	}
	public function getEmail()
	{
		return $this->email = $email;
	}
	public function setEmail($email)
	{
		$this->email = $email;
	}
	public function getCantidadSucursales()
	{
		return $this->cantidadSucursales = $cantidadSucursales;
	}
	public function setCantidadSucursales($cantidadSucursales)
	{
		$this->cantidadSucursales = $cantidadSucursales;
	}
	public function getLogo()
	{
		return $this->logo = $logo;
	}
	public function setLogo($logo)
	{
		$this->logo = $logo;
	}

	/*public function agregarRestaurante($idUsuario, $idCodigo, $nombreRestaurante, $direccionRestaurante, $telefonoRestaurante, $ciudad, $email, $cantidadSucursales)
	{


		$con = $this->conectar();
		
		$sql = "INSERT INTO restaurante (idRestaurante, idUsuario, codigoTributario, nombreRestaurante, direccionRestaurante, telefonoRestaurante, ciudad, email, cantidadSucursales) VALUES(0,$idUsuario, '$idCodigo', '$nombreRestaurante', '$direccionRestaurante', '$telefonoRestaurante', '$ciudad', '$email', $cantidadSucursales);";

		$info = $con->query($sql);

		var_dump($con->error);
		die();
	}*/
}
 ?>