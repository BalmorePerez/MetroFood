<?php
require_once 'Conexion.php';
/**
* 
*/
class Usuario extends Conexion
{
	private $nombreUsuario;
	private $contrasenha;
	private $idTipoUsuario;
	public $ultimoId;
	function __construct()
	{
		parent::__construct();
	}

	public function getNombreUsuario()
	{
		return $this->nombreUsuario;
	}
	public function setNombreUsuario($nombreUsuario)
	{
		$this->nombreUsuario = $nombreUsuario;
	}
	public function getContrasenha()
	{
		return $this->contrasenha;
	}
	public function setContrasenha($contrasenha)
	{
		$this->contrasenha = $contrasenha;
	}
	public function getIdTipoUsuario()
	{
		return $this->idTipoUsuario;
	}
	public function setIdTipoUsuario($idTipoUsuario)
	{
		$this->idTipoUsuario = $idTipoUsuario;
	}

	public function registrarUsuario($nombreUsuario, $contrasenha, $idTipoUsuario, $idCodigo, $nombreRestaurante, $direccionRestaurante, $telefonoRestaurante, $ciudad, $email, $cantidadSucursales)
	{
		$con = $this->conectar();
		$sql1 = "INSERT INTO usuario(nombreUsuario, contrasenha, idTipoUsuario) VALUES ('$nombreUsuario', '$contrasenha', '$idTipoUsuario');";
		$info = $con->query($sql1);
		$ultimoId = mysqli_insert_id($con);

		$sql2= "INSERT INTO restaurante (idUsuario, codigoTributario, nombreRestaurante, direccionRestaurante, telefonoRestaurante, ciudad, email, cantidadSucursales) VALUES($ultimoId, '$idCodigo', '$nombreRestaurante', '$direccionRestaurante', '$telefonoRestaurante', '$ciudad', '$email', $cantidadSucursales);";
		
		$info2 = $con->query($sql2);

		header("Location: ../views/login/login.php");
	}

	public function registrarCliente($nombreUsuario, $contrasenha, $idTipoUsuario, $nombre, $apellido, $edad, $dui, $telefonoCliente, $direccion, $correo)
	{
		$con = $this->conectar();
		$sql1 = "INSERT INTO usuario(nombreUsuario, contrasenha, idTipoUsuario) VALUES ('$nombreUsuario', '$contrasenha', '$idTipoUsuario');";
		$info = $con->query($sql1);
		$ultimoId = mysqli_insert_id($con);

		$sql2 = "INSERT INTO cliente (idUsuario, nombre, apellido, edad, DUI,telefonoCliente, direccion, correo) VALUES ($ultimoId, '$nombre', '$apellido', $edad, '$dui', '$telefonoCliente', '$direccion', '$correo');";

		$info2 = $con->query($sql2);

		header("Location: ../views/login/login.php");
	}


	public function iniciarSesion($nombreUsuario, $contrasenha)
	{
		$con = $this->conectar();
		$sql = "SELECT us.nombreUsuario, us.contrasenha, ro.rol FROM usuario AS us JOIN rol AS ro WHERE us.idTipoUsuario = ro.idTipoUsuario and us.nombreUsuario = '".$nombreUsuario."' and us.contrasenha = '".$contrasenha."'";
			$info = $con->query($sql);
			if ($info->num_rows>0) {
				$data = $info->fetch_assoc();
				session_start();
				$_SESSION['ROL']=$data['rol'];
				header("Location: ../views/dashboard/dashboard.php");
				//Mirar: Como insertar datos de una tabla con campo de Auto-incremento en otra tabla con mysqli_insert_id por: Steve
				//$ultimoID= mysqli->insert_id;
				//$ultimoID= mysqli_insert_id($con);
			}
			else
			{
				header("Location: ../views/login/login.php");
			}
	}
}
 ?>