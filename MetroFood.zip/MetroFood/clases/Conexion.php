<?php 
/**
* 
*/
class Conexion
{
	private $host;
	private $user;
	private $password;
	private $database;
	public function __construct()
	{
		$data = require_once '../app/config.php';
		$this->host = $data['host'];
		$this->user = $data['user'];
		$this->password = $data['password'];
		$this->database = $data['database'];
	}

	public function conectar()
	{
		$con = new mysqli($this->host, $this->user, $this->password, $this->database);
		if ($con -> connect_errno) {
			echo "Tienes un error de conexión";
			die();
		}
		return $con;
	}
}
/*$host = "localhost";
$user = 'root';
$password = '';
$dataBase = 'basemetrofood2';

$table_db1 = 'Usuario';

$conexion = new mysqli($host, $user, $password, $dataBase);

if ($conexion->connect_errno) {
	echo "Error al conectar con la base de datos.";
	exit();*/
 ?>