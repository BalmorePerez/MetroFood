<?php 
/**
* 
*/
class Cliente
{
	protected $idUsuario;
	protected $nombre;
	protected $apellido;
	protected $edad;
	protected $dui;
	protected $telefonoCliente;
	protected $direccion;
	protected $correo;
	function __construct()
	{
		# code...
	}

	public function getIdUsuario()
	{
		return $this->idUsuario;
	}
	public function setIdUsuario($idUsuario)
	{
		$this->idUsuario = $idUsuario;
	}
	public function getNombre()
	{
		return $this->nombre;
	}
	public function setNombre($nombre)
	{
		$this->nombre = $nombre;
	}
	public function getApellido()
	{
		return $this->apellido;
	}
	public function setApellido($apellido)
	{
		$this->apellido = $apellido;
	}
	public function getEdad()
	{
		return $this->edad;
	}
	public function setEdad($edad)
	{
		$this->edad = $edad;
	}
	public function getDui()
	{
		return $this->dui;
	}
	public function setDui($dui)
	{
		$this->dui = $dui;
	}
	public function getTelefonoCliente()
	{
		return $this->telefonoCliente;
	}
	public function setTelefonoCliente($telefonoCliente)
	{
		$this->telefonoCliente = $telefonoCliente;
	}
	public function getDireccion()
	{
		return $this->direccion;
	}
	public function setDireccion($direccion)
	{
		$this->direccion = $direccion;
	}
	public function getCorreo()
	{
		return $this->correo;
	}
	public function setCorreo($correo)
	{
		$this->correo = $correo;
	}

}
 ?>