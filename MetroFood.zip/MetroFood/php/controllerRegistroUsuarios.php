<?php 
include ('../clases/Usuario.php');
include ('../clases/Restaurante.php');

if (isset($_POST['enviarDatosClientes'])) 
{
	registrarUsuarioYCliente();
}

else if (isset($_POST['enviarDatosRestaurante'])) 
{	
	registrarUsuarioYRestaurante();
}

	function registrarUsuarioYRestaurante()
	{
		$nombreUsuario = $_POST['nombreUsuario'];
		$contrasenha = $_POST['repeatPassword'];
		$idTipoUsuario = 3;

		$idCodigo = $_POST['codigoTributario'];
		$nombreRestaurante = $_POST['nombreRestaurante'];
		$direccionRestaurante = $_POST['direccion'];
		$telefonoRestaurante = $_POST['telefono'];
		$ciudad = $_POST['ciudad'];
		$email = $_POST['email'];
		$cantidadSucursales = $_POST['cantidadSucursales'];

		$objUsua = new Usuario();
		$objUsua->registrarUsuario($nombreUsuario, $contrasenha, $idTipoUsuario, $idCodigo, $nombreRestaurante, $direccionRestaurante, $telefonoRestaurante, $ciudad, $email, $cantidadSucursales);

		/*$objRestaurante = new Restaurante();
		$objRestaurante->agregarRestaurante($idUsuario, $idCodigo, $nombreRestaurante, $direccionRestaurante, $telefonoRestaurante, $ciudad, $email, $cantidadSucursales);*/

	}

	function registrarUsuarioYCliente()
	{
		$nombreUsuario = $_POST['nombreUsuario'];
		$contrasenha = $_POST['repeatPassword'];
		$idTipoUsuario = 2;

		$nombre = $_POST['nombreCliente'];
		$apellido = $_POST['apellidoCliente'];
		$edad = $_POST['edadCliente'];
		$dui = $_POST['dui'];
		$telefonoCliente = $_POST['telefonoCliente'];
		$direccion = $_POST['direccionCliente'];
		$correo = $_POST['emailCliente'];

		$objUs = new Usuario();
		$objUs->registrarCliente($nombreUsuario, $contrasenha, $idTipoUsuario, $nombre, $apellido, $edad, $dui, $telefonoCliente, $direccion, $correo);
	}
	


 ?>